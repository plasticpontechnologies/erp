import React, { Component } from "react";
import axios from "axios";

import {  BiStar, BiEdit, BiDish, BiTable, BiPencil, BiSearch, BiMinus, BiPlus, BiExpand, BiX} from "react-icons/bi";

class Dishes extends Component {
    refresh = () => {
        window.location.reload(false);
    };
    constructor(props) {
        super(props);
        this.state = {
            isActive: true,
            issActive: true,
            values: [],
            values: {
                dishId:"",
            dishName:"", 
            dishPrice:""
            },
            isSubmitting: false,
            isError: false
           
        };
        // this.handleSubmit = this.handleSubmit.bind(this);
        // this.handleChange = this.handleChange.bind(this);
        
        this.fullscreenModal = React.createRef();
    } 
    handleBack() {
        this.props.history.goBack()
    }
    openContentFullscreen = () => {
        const elem = this.fullscreenModal.current;
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        }
    }
    handleShow = () => {
        this.setState({ isActive: false });
    };
    handleHide = () => {
        this.setState({ isActive: true });
    };
    haandleShow = () => {
        this.setState({ issActive: false });
    };
    haandleHide = () => {
        this.setState({ issActive: false });
    }

    submitForm = async e => {
      e.preventDefault();
      console.log(this.state);
      this.setState({ isSubmitting: true });
  
      const res = await fetch("http://83.136.219.101:8080/erp/canteen/saveDishDetails", {
        method: "POST",
        body: JSON.stringify(this.state.values),
        headers: {
          "Content-Type": "application/json"
        }
      });
      this.setState({ isSubmitting: false });
      const data = await res.json();
      !data.hasOwnProperty("error")
        ? this.setState({ message: data.success })
        : this.setState({ message: data.error, isError: true });
  
      setTimeout(
        () =>
          this.setState({
            isError: false,
            message: "",
            values: { dishId:"",dishName: "", dishPrice: "" }
          }),
        1600
      );
    };
  
    handleInputChange = e =>
      this.setState({
        values: { ...this.state.values, [e.target.name]: e.target.value }
      });
    
         
    
        

  render() {
  
    return (
        <div className="App">
            <div id="canteen">
                <span className="canteen-button-alignment">
                    <span className="btn btn-canteen">
                    <i className="fa"><BiDish onClick={this.refresh} /></i>
                    </span>
                </span>
                <ol className="crumb">
                    <li style={{ fontSize: "14px" }}>Canteen</li>
                    <li style={{ fontSize: "14px" }} >Dishes</li>
                </ol>

                <div style={{ float: "right" }}>
                    <span className="canteen-button-alignment">
                        <span className="btn btn-canteen">
                            <i className="fa"><BiStar /></i>
                        </span>
                    </span>
                    <div style={{ zIndex: 9999, right: "0", float: "right", marginTop: "10px" }}>
                        <span>
                            <a href="#" style={{ fontSize: "14px" }}>My Favorite</a>
                        </span>
                    </div>
                </div>
            </div>

            {this.state.issActive &&  <div id="contrast" ref={this.fullscreenModal }   show={this.state.show} handleClose={this.hideModal}  className="ng-scope" style={{ opacity: "1" }}>
                <section>
                    <div className="row">
                        <article className="col-sm-12 col-md-12 col-lg-5">
                            <div className="dish master">
                                <header role="heading">
                                <div className="jarviswidget-ctrls" role="menu">
                                            <a href="#" className="button-icon jarviswidget-toggle-btn">
                                                {this.state.isActive ? (<BiMinus className="fa" onClick={this.handleShow} />
                                                ) : (
                                                    <BiPlus className="fa" onClick={this.handleHide} />
                                                )}
                                            </a>
                                            <a href="#" className="button-icon jarviswidget-fullscreen-btn">
                                                <i onClick={this.openContentFullscreen}><BiExpand className="fa" /></i>
                                                {/* {this.state.isActive ? (<BiExpand className="fa" onClick={this.openContentFullscreen} />
                                                        ) : ( 
                                                        <BiExpand className="fa" onClick={this.handleHide} />
                                                        )} */}
                                            </a>
                                            <a href="#" className="button-icon jarviswidget-delete-btn">
                                                {this.state.issActive ? (<BiX className="fa" onClick={this.haandleShow} />
                                                ) : (
                                                    <BiX className="fa" onClick={this.haandleHide} />
                                                )}
                                            </a>
                                        </div>
                                    <span className="master-icon">
                                        <i className="fa">
                                            <BiEdit />
                                        </i>
                                    </span>
                                    <h2>Add Dishes</h2>
                                </header>
                                <div>
                                {this.state.isActive && <div>
                                        <form className="entry-form" onSubmit={this.submitForm}>
                                        <div>
                        <input
                            type="text"
                            name="dishId"
                            value={this.state.values.dishId}
                            onChange={this.handleInputChange}
                        />
                    </div>
                                            <section>
                                         <label class="label ng-binding">Dishe Name
                                         </label>
                                         <label class="input">
                                         {/* <select id="Select" style={{ width: "100%", height: "33px" }}>
                                                            <option>Dishe Name </option>
                                                        {
                                        this.state.values.map((obj) => {
                                            return <option key={obj.dishId}>{obj.dishName}</option>
                                        })
                                      }
                                      
                                                        </select> */}

										<input type="text" className="input-sm" 
                                        name="dishName" 
                                        value={this.state.values.dishName}
              onChange={this.handleInputChange}
                                         placeholder="Dishe Name"  />
									    </label>
                                                <div style={{ paddingTop: "30px" }}>
                                                    <hr />
                                                </div>
                                            </section>

                                            <section style={{paddingTop: "20px"}}>
                                         <label class="label ng-binding">Price</label>
                                         <label class="input">
                                         {/* <select id="Select" style={{ width: "100%", height: "33px" }}>
                                                            <option>Price</option>
                                                        {
                                        this.state.values.map((obj) => {
                                            return <option key={obj.dishId}>{obj.dishPrice}</option>
                                        })
                                      }
                                      
                                                        </select>  */}
										<input type="text" className="input-sm" 
                                        name="dishPrice"
                                        value={this.state.values.dishPrice}
                                        onChange={this.handleInputChange}
                                        placeholder="Price"   />
									    </label>
                                                <div style={{ paddingTop: "30px" }}>
                                                    <hr />
                                                </div>
                                            </section>
                                            <footer>
                                                <button type="button" id="submit"
                                                    class="btn btn-primary ng-binding">Save</button>
                                                <button type="button"
                                                    class="btn btn-default ng-binding">Back</button>
                                            </footer>
                                        </form>
                                        <div className={`message ${this.state.isError && "error"}`}>
          {this.state.isSubmitting ? "Submitting..." : this.state.message}
        </div>
                                    </div>
                             }
                                </div>
                            </div>
                        </article>

                        <article className="col-sm-12 col-md-12 col-lg-5">
                            <div className="dishe master">
                                <header role="heading">
                                <div className="jarviswidget-ctrls" role="menu">
                                            <a href="#" className="button-icon jarviswidget-toggle-btn">
                                                {this.state.isActive ? (<BiMinus className="fa" onClick={this.handleShow} />
                                                ) : (
                                                    <BiPlus className="fa" onClick={this.handleHide} />
                                                )}
                                            </a>
                                            <a href="#" className="button-icon jarviswidget-fullscreen-btn">
                                                <i onClick={this.openContentFullscreen}><BiExpand className="fa" /></i>
                                                {/* {this.state.isActive ? (<BiExpand className="fa" onClick={this.openContentFullscreen} />
                                                        ) : ( 
                                                        <BiExpand className="fa" onClick={this.handleHide} />
                                                        )} */}
                                            </a>
                                            <a href="#" className="button-icon jarviswidget-delete-btn">
                                                {this.state.issActive ? (<BiX className="fa" onClick={this.haandleShow} />
                                                ) : (
                                                    <BiX className="fa" onClick={this.haandleHide} />
                                                )}
                                            </a>
                                        </div>
                                    <span className="master-icon">
                                        <i className="fa">
                                            <BiTable />
                                        </i>
                                    </span>
                                    <h2>Dishes List</h2>
                                </header>
                                <div>
                                {this.state.isActive && <div>
                                    <div className="col-xs-12 col-sm-6">
                                                <div id="canteen_basic_filter" className="canteen_filter">
                                                    <label>
                                                        <span className="input-group-addon">
                                                            <i className="gly">
                                                              <BiSearch />
                                                              </i>
                                                            </span>
                                                            <input type="search" className="form-control"></input>
                                                     </label>
                                                </div>
                                            </div>
                                            <div style={{paddingTop: "10px"}}>
                                        <table>
                                            <tr>
                                                <th>Action</th>
                                                <th>Dish Name</th>
                                                <th>Price</th>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <i className="fa">
                                                        <BiPencil />
                                                    </i>
                                                </td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </table>
                                        </div>
                                     <div className="dt-toolbar-footer">
                                        <div className="col-xs-12 col-sm-6" style={{float: "right"}}>
                                            <div className="canteen_paginate paging_simple_numbers" id="dt_basic_paginate">
                                                <ul className="pagination pagination-sm">
                                                    <li className="paginate_button previous disabled" aria-controls="dt_basic" tabindex="0" id="dt_basic_previous">
                                                        <a href="#">Previous</a>
                                                    </li>
                                                    <li className="paginate_button active">
                                                        <a href="#">1</a>
                                                    </li>

                                                    <li className="paginate_button next disabled" >
                                                        <a href="#">Next</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
  }
                                </div>
                            </div>
                        </article>
                    </div>
                </section>
            </div>
  }
      </div>
    )
  }
}

export default Dishes;